// utils/cookies.js
export const ACCESS_COOKIE  = 'access_token';
export const REFRESH_COOKIE = 'refresh_token';
